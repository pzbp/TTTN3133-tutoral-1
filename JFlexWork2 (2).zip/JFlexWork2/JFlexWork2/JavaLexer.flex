/* JavaLexer.flex */

%%

%class JavaLexer
%type Token
%function nextToken     // 将生成的方法名改为 nextToken，便于调用
%line
%column

%{
  // 可选的用户代码
%}

/* 正则定义 */
ID = [a-zA-Z_][a-zA-Z0-9_]*
INT = [0-9]+
FLOAT = [0-9]+"."[0-9]+
STRING = \"[^\"]*\"
CHAR_LITERAL = "'"([^'\\]|\\.)*"'"
WHITE = [ \t\r\n]+
COMMENT_LINE = "//"[^\r\n]*
COMMENT_BLOCK = "/*"([^*]|\*+[^*/])*"*"+"/"

%%

/* 规则段 */

/* 忽略空白和注释 */
{WHITE}          { /* 忽略空白 */ }
{COMMENT_LINE}   { /* 忽略单行注释 */ }
{COMMENT_BLOCK}  { /* 忽略多行注释 */ }

/* 关键字 */
"if"             { return new Token(Token.IF, yyline+1, yycolumn+1, yytext()); }
"else"           { return new Token(Token.ELSE, yyline+1, yycolumn+1, yytext()); }
"for"            { return new Token(Token.FOR, yyline+1, yycolumn+1, yytext()); }
"int"            { return new Token(Token.INT_KEYWORD, yyline+1, yycolumn+1, yytext()); }
"float"          { return new Token(Token.FLOAT_KEYWORD, yyline+1, yycolumn+1, yytext()); }
"double"         { return new Token(Token.DOUBLE_KEYWORD, yyline+1, yycolumn+1, yytext()); }
"char"           { return new Token(Token.CHAR_KEYWORD, yyline+1, yycolumn+1, yytext()); }
"boolean"        { return new Token(Token.BOOLEAN_KEYWORD, yyline+1, yycolumn+1, yytext()); }
"void"           { return new Token(Token.VOID, yyline+1, yycolumn+1, yytext()); }
"class"          { return new Token(Token.CLASS, yyline+1, yycolumn+1, yytext()); }
"public"         { return new Token(Token.PUBLIC, yyline+1, yycolumn+1, yytext()); }
"private"        { return new Token(Token.PRIVATE, yyline+1, yycolumn+1, yytext()); }
"static"         { return new Token(Token.STATIC, yyline+1, yycolumn+1, yytext()); }
"return"         { return new Token(Token.RETURN, yyline+1, yycolumn+1, yytext()); }
"true"           { return new Token(Token.TRUE, yyline+1, yycolumn+1, yytext()); }
"false"          { return new Token(Token.FALSE, yyline+1, yycolumn+1, yytext()); }
"null"           { return new Token(Token.NULL, yyline+1, yycolumn+1, yytext()); }

/* 标识符、数字、字符串、字符 */
{ID}             { return new Token(Token.ID, yyline+1, yycolumn+1, yytext()); }
{INT}            { return new Token(Token.INT, yyline+1, yycolumn+1, yytext()); }
{FLOAT}          { return new Token(Token.FLOAT, yyline+1, yycolumn+1, yytext()); }
{STRING}         { return new Token(Token.STRING, yyline+1, yycolumn+1, yytext()); }
{CHAR_LITERAL}   { return new Token(Token.CHAR_LITERAL, yyline+1, yycolumn+1, yytext()); }

/* 运算符 */
"="              { return new Token(Token.ASSIGN, yyline+1, yycolumn+1, yytext()); }
"=="             { return new Token(Token.EQ, yyline+1, yycolumn+1, yytext()); }
"!="             { return new Token(Token.NE, yyline+1, yycolumn+1, yytext()); }
"<"              { return new Token(Token.LT, yyline+1, yycolumn+1, yytext()); }
"<="             { return new Token(Token.LE, yyline+1, yycolumn+1, yytext()); }
">"              { return new Token(Token.GT, yyline+1, yycolumn+1, yytext()); }
">="             { return new Token(Token.GE, yyline+1, yycolumn+1, yytext()); }
"+"              { return new Token(Token.PLUS, yyline+1, yycolumn+1, yytext()); }
"-"              { return new Token(Token.MINUS, yyline+1, yycolumn+1, yytext()); }
"*"              { return new Token(Token.MULT, yyline+1, yycolumn+1, yytext()); }
"/"              { return new Token(Token.DIV, yyline+1, yycolumn+1, yytext()); }
"%"              { return new Token(Token.MOD, yyline+1, yycolumn+1, yytext()); }
"++"             { return new Token(Token.INC, yyline+1, yycolumn+1, yytext()); }
"--"             { return new Token(Token.DEC, yyline+1, yycolumn+1, yytext()); }
"&&"             { return new Token(Token.AND, yyline+1, yycolumn+1, yytext()); }
"||"             { return new Token(Token.OR, yyline+1, yycolumn+1, yytext()); }
"!"              { return new Token(Token.NOT, yyline+1, yycolumn+1, yytext()); }
"&"              { return new Token(Token.BIT_AND, yyline+1, yycolumn+1, yytext()); }
"|"              { return new Token(Token.BIT_OR, yyline+1, yycolumn+1, yytext()); }
"^"              { return new Token(Token.BIT_XOR, yyline+1, yycolumn+1, yytext()); }
"~"              { return new Token(Token.BIT_NOT, yyline+1, yycolumn+1, yytext()); }
"<<"             { return new Token(Token.LSHIFT, yyline+1, yycolumn+1, yytext()); }
">>"             { return new Token(Token.RSHIFT, yyline+1, yycolumn+1, yytext()); }
">>>"            { return new Token(Token.URSHIFT, yyline+1, yycolumn+1, yytext()); }
"?"              { return new Token(Token.QUESTION, yyline+1, yycolumn+1, yytext()); }
":"              { return new Token(Token.COLON, yyline+1, yycolumn+1, yytext()); }

/* 分隔符 */
";"              { return new Token(Token.SEMI, yyline+1, yycolumn+1, yytext()); }
","              { return new Token(Token.COMMA, yyline+1, yycolumn+1, yytext()); }
"."              { return new Token(Token.DOT, yyline+1, yycolumn+1, yytext()); }
"("              { return new Token(Token.LPAREN, yyline+1, yycolumn+1, yytext()); }
")"              { return new Token(Token.RPAREN, yyline+1, yycolumn+1, yytext()); }
"{"              { return new Token(Token.LBRACE, yyline+1, yycolumn+1, yytext()); }
"}"              { return new Token(Token.RBRACE, yyline+1, yycolumn+1, yytext()); }
"["              { return new Token(Token.LBRACKET, yyline+1, yycolumn+1, yytext()); }
"]"              { return new Token(Token.RBRACKET, yyline+1, yycolumn+1, yytext()); }

/* 错误处理：任意字符 */
.                { return new Token(Token.ERROR, yyline+1, yycolumn+1, yytext()); }