public class Token {
    // 关键字
    public static final int IF = 1;
    public static final int ELSE = 2;
    public static final int FOR = 3;
    public static final int INT_KEYWORD = 4;
    public static final int FLOAT_KEYWORD = 5;
    public static final int DOUBLE_KEYWORD = 6;
    public static final int CHAR_KEYWORD = 7;
    public static final int BOOLEAN_KEYWORD = 8;
    public static final int VOID = 9;
    public static final int CLASS = 10;
    public static final int PUBLIC = 11;
    public static final int PRIVATE = 12;
    public static final int STATIC = 13;
    public static final int RETURN = 14;
    public static final int TRUE = 15;
    public static final int FALSE = 16;
    public static final int NULL = 17;

    // 标识符、字面量
    public static final int ID = 18;
    public static final int INT = 19;
    public static final int FLOAT = 20;
    public static final int STRING = 21;
    public static final int CHAR_LITERAL = 22;

    // 运算符
    public static final int ASSIGN = 23;    // =
    public static final int EQ = 24;        // ==
    public static final int NE = 25;        // !=
    public static final int LT = 26;        // <
    public static final int LE = 27;        // <=
    public static final int GT = 28;        // >
    public static final int GE = 29;        // >=
    public static final int PLUS = 30;      // +
    public static final int MINUS = 31;     // -
    public static final int MULT = 32;      // *
    public static final int DIV = 33;       // /
    public static final int MOD = 34;       // %
    public static final int INC = 35;       // ++
    public static final int DEC = 36;       // --
    public static final int AND = 37;       // &&
    public static final int OR = 38;        // ||
    public static final int NOT = 39;       // !
    public static final int BIT_AND = 40;   // &
    public static final int BIT_OR = 41;    // |
    public static final int BIT_XOR = 42;   // ^
    public static final int BIT_NOT = 43;   // ~
    public static final int LSHIFT = 44;    // <<
    public static final int RSHIFT = 45;    // >>
    public static final int URSHIFT = 46;   // >>>
    public static final int QUESTION = 47;  // ?
    public static final int COLON = 48;     // :

    // 分隔符
    public static final int SEMI = 49;      // ;
    public static final int COMMA = 50;     // ,
    public static final int DOT = 51;       // .
    public static final int LPAREN = 52;    // (
    public static final int RPAREN = 53;    // )
    public static final int LBRACE = 54;    // {
    public static final int RBRACE = 55;    // }
    public static final int LBRACKET = 56;  // [
    public static final int RBRACKET = 57;  // ]

    // 错误
    public static final int ERROR = -1;

    public int type;
    public int line;
    public int col;
    public String value;

    public Token(int t, int l, int c) {
        this(t, l, c, null);
    }

    public Token(int t, int l, int c, String v) {
        type = t;
        line = l;
        col = c;
        value = v;
    }

    public String getTypeName() {
        switch (type) {
            case IF: return "IF";
            case ELSE: return "ELSE";
            case FOR: return "FOR";
            case INT_KEYWORD: return "INT_KEYWORD";
            case FLOAT_KEYWORD: return "FLOAT_KEYWORD";
            case DOUBLE_KEYWORD: return "DOUBLE_KEYWORD";
            case CHAR_KEYWORD: return "CHAR_KEYWORD";
            case BOOLEAN_KEYWORD: return "BOOLEAN_KEYWORD";
            case VOID: return "VOID";
            case CLASS: return "CLASS";
            case PUBLIC: return "PUBLIC";
            case PRIVATE: return "PRIVATE";
            case STATIC: return "STATIC";
            case RETURN: return "RETURN";
            case TRUE: return "TRUE";
            case FALSE: return "FALSE";
            case NULL: return "NULL";
            case ID: return "ID";
            case INT: return "INT";
            case FLOAT: return "FLOAT";
            case STRING: return "STRING";
            case CHAR_LITERAL: return "CHAR_LITERAL";
            case ASSIGN: return "ASSIGN";
            case EQ: return "EQ";
            case NE: return "NE";
            case LT: return "LT";
            case LE: return "LE";
            case GT: return "GT";
            case GE: return "GE";
            case PLUS: return "PLUS";
            case MINUS: return "MINUS";
            case MULT: return "MULT";
            case DIV: return "DIV";
            case MOD: return "MOD";
            case INC: return "INC";
            case DEC: return "DEC";
            case AND: return "AND";
            case OR: return "OR";
            case NOT: return "NOT";
            case BIT_AND: return "BIT_AND";
            case BIT_OR: return "BIT_OR";
            case BIT_XOR: return "BIT_XOR";
            case BIT_NOT: return "BIT_NOT";
            case LSHIFT: return "LSHIFT";
            case RSHIFT: return "RSHIFT";
            case URSHIFT: return "URSHIFT";
            case QUESTION: return "QUESTION";
            case COLON: return "COLON";
            case SEMI: return "SEMI";
            case COMMA: return "COMMA";
            case DOT: return "DOT";
            case LPAREN: return "LPAREN";
            case RPAREN: return "RPAREN";
            case LBRACE: return "LBRACE";
            case RBRACE: return "RBRACE";
            case LBRACKET: return "LBRACKET";
            case RBRACKET: return "RBRACKET";
            case ERROR: return "ERROR";
            default: return "UNKNOWN";
        }
    }

    @Override
    public String toString() {
        String val = (value == null) ? "" : ", val=" + value;
        return String.format("(type=%s, line=%d, col=%d%s)",
                getTypeName(), line, col, val);
    }
}