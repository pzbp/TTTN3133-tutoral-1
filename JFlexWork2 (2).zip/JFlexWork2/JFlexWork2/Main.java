import java.io.*;
import java.nio.charset.StandardCharsets;

public class Main {
    public static void main(String[] args) {
        if (args.length < 1) {
            System.out.println("Usage: java Main <input file>");
            return;
        }

        String inputFile = args[0];
        // 自动生成 CSV 文件名：将输入文件的扩展名替换为 .csv
        String csvFile = inputFile.replaceAll("\\.[^.]*$", "") + ".csv";
        int errorCount = 0;

        try (Reader rd = new InputStreamReader(
                new FileInputStream(inputFile), StandardCharsets.UTF_8);
             PrintWriter csvWriter = new PrintWriter(
                     new OutputStreamWriter(new FileOutputStream(csvFile), StandardCharsets.UTF_8))) {

            JavaLexer lex = new JavaLexer(rd);
            Token t;

            // 写入 CSV 表头
            csvWriter.println("Lexeme,Token Type,Token (full)");

            System.out.println("=== Lexical Analysis Result: " + inputFile + " ===");
            System.out.printf("%-20s %-6s %-6s %s%n", "Token Type", "Line", "Col", "Value");
            System.out.println("---------------------------------------------");

            while ((t = lex.nextToken()) != null) {
                // 控制台输出
                System.out.printf("%-20s %-6d %-6d %s%n",
                        t.getTypeName(), t.line, t.col,
                        (t.value == null ? "" : t.value));

                // CSV 输出
                String lexeme = (t.value != null) ? t.value : "";
                String tokenType = t.getTypeName();
                String fullToken = String.format("(type=%s,line=%d,col=%d%s)",
                        tokenType, t.line, t.col,
                        (t.value != null ? ",val=" + t.value : ""));

                // 处理 CSV 中的逗号：如果字段包含逗号，用双引号包裹
                if (lexeme.contains(",")) {
                    lexeme = "\"" + lexeme + "\"";
                }
                if (fullToken.contains(",")) {
                    fullToken = "\"" + fullToken + "\"";
                }

                csvWriter.println(lexeme + "," + tokenType + "," + fullToken);

                if (t.type == Token.ERROR) {
                    errorCount++;
                }
            }

            System.out.println("---------------------------------------------");
            if (errorCount > 0) {
                System.out.println("Found " + errorCount + " lexical errors!");
            } else {
                System.out.println("No lexical errors found.");
            }

            System.out.println("CSV file generated: " + csvFile);

        } catch (FileNotFoundException e) {
            System.err.println("File not found: " + inputFile);
        } catch (IOException e) {
            System.err.println("Error reading file: " + e.getMessage());
        }
    }
}